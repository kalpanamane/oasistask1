# oasis_task_1
# created simple landing webpage for headphones using html and css
